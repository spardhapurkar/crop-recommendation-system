from django.db import models
class Contact(models.Model):
    name = models.CharField(max_length=100)
    phonenumber = models.CharField(max_length=15)
    branch = models.CharField(max_length=50)
    year = models.IntegerField()
    time = models.DateTimeField()
    class Meta:
        app_label = 'home'
    def __str__(self):
        return self.name

class Signup(models.Model):
    name = models.CharField(max_length=30, default="Default Name")
    username = models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    confirm_password=models.CharField(max_length=30)
    time = models.DateTimeField()
    def __str__(self):
        return self.username